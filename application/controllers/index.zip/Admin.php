<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Admin extends CI_Controller
{
    ///check login
    function __construct()
    {
        parent::__construct();
        ///load Helper
        $this->load->helper('functions_helper');
        $this->load->helper('queries_helper');

        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
    }

    ///dashboard
    public function index()
    {
        $title = 'Dashboard';
        $data = array();
        $page = 'admin/dashboard';
        AdminView($page, $data, $title);
    }


    //CompanyDatabase
    public function CompanyDatabase()
    {

        $records = GetCommonData();
        $projects = $records->companies[0]->projects;
        $_SESSION['company_email'] = $records->companies[0]->employments[0]->email;
        if (isset($projects) && (!empty($projects))) {
            $count = count($projects);
            for ($i = 0; $i < $count; $i++) {
                //data
                $data = array();
                $data['id'] = $projects[$i]->id;
                $data['name'] = $projects[$i]->name;
                $data['color'] = $projects[$i]->color;
                $data['clientId'] = $projects[$i]->clientId;
                $data['endDate'] = $projects[$i]->endDate;

                $check = getByWhere('projects', '*', array('id' => $projects[$i]->id));
                if (empty($check)) {
                    addNew('projects', $data);
                } else {
                    updateByWhere('projects', $data, array('id' => $projects[$i]->id));
                }
            }
        }

        $empl = $records->companies[0]->employments;
        if (isset($empl) && !empty($empl)) {
            $count = count($empl);
            $row = array();

            for ($i = 0; $i < $count; $i++) {
                $tr = '';
                $tr = $tr . "<tr>" . "<td>" . $empl[$i]->id . "</td>" . "<td>" . $empl[$i]->name . "</td>" . "<td>" . $empl[$i]->email . "</td>";
                $button = " ";
                $button .= '<td><a type="button" href="' . base_url('employee/' . base64_encode($empl[$i]->id)) . '" class="btn btn-dark btn-lg btn-block">Check Detail</a></td></tr>';
                $tr = $tr . $button;
                array_push($row, $tr);
            }
        }


        $title = 'Employee List';
        $data['count'] = $count;
        $data['tr'] = $row;
        $page = 'admin/employees';
        AdminView($page, $data, $title);
    }


    ///SingleEmployeeData
    public function SingleEmployeeData()
    {
        $id = $this->uri->segment(2);
        $id = base64_decode($id);
        $records = GetCommonData();
        $_SESSION['company_email'] = $records->companies[0]->employments[0]->email;
        $data = array();
        ///company Data
        $data['company'] = array(
            'id' => $records->companies[0]->id,
            'name' => $records->companies[0]->name,
            'isAdmin' => $records->companies[0]->isAdmin,
        );


        $empl = $records->companies[0]->employments;
        if (isset($empl) && !empty($empl)) {
            $count = count($empl);
            for ($i = 0; $i < $count; $i++) {
                if ($empl[$i]->id == $id) {
                    // echo $empl[$i]->config->autoPauseMinutes; 
                    // die;
                    //   echo '<pre>';
                    //   print_r($empl[$i]);
                    //   echo '</pre>';
                    //   die;


                    ///profile details
                    $data['profile'] = array(
                        "id" => $empl[$i]->id,
                        "name" => $empl[$i]->name,
                        "email" => $empl[$i]->email,
                        "registered" => $empl[$i]->registered,
                        "lastActive" => $empl[$i]->lastActive,
                        "payRate" => $empl[$i]->payRate,
                        "endDate" => $empl[$i]->endDate,
                        "inPause" => $empl[$i]->inPause,
                        "activityStatus" => $empl[$i]->activityStatus,
                    );

                    ///config details
                    $data['config'] = array(
                        "autoPauseMinutes" => $empl[$i]->config->autoPauseMinutes,
                        "disableOfflineTime" => $empl[$i]->config->disableOfflineTime,
                        "disableScreenshotNotification" => $empl[$i]->config->disableScreenshotNotification,
                        "disableActivityLevel" => $empl[$i]->config->disableActivityLevel,
                        "currency" => $empl[$i]->config->currency,
                        "weeklyLimit" => $empl[$i]->config->weeklyLimit,
                        "weekStartDay" => $empl[$i]->config->weekStartDay,
                        "disableAppTracking" => $empl[$i]->config->disableAppTracking,
                        "dateFormat" => $empl[$i]->config->dateFormat,
                    );



                    ///Total projects
                    $data['totalProjects'] = count($empl[$i]->projects);
                    $data['projects'] = $empl[$i]->projects;
                }
            }
        }
        $title = 'Single Employee Details';
        $page = 'admin/employee';
        AdminView($page, $data, $title);
    }


    ///GetActivitiesData
    public function GetActivitiesData()
    {
        $records = GetCommonData();
        $empl = $records->companies[0]->employments;
        if (isset($empl) && !empty($empl)) {
            $count = count($empl); 
            for ($i = 0; $i < $count; $i++) {
                $getemp=getByWhere('employee','*',array('emplId'=>$empl[$i]->id));
                if($getemp)
                {
                    $fromtime=$getemp[0]->fromtime;
                    $to=IntegerDate(date('Y-m-d h:m:s'));
                    $check=GetActivityTime($empl[$i]->id,$fromtime,$to);
                    if($check)
                    {
                        updateByWhere('employee',array('fromtime'=>$to),array('emplId'=>$empl[$i]->id));
                    }



                }
                else
                {
                    addNew('employee',array('emplId'=>$empl[$i]->id,'fromtime'=>IntegerDate(date('Y-m-d h:m:s'))));
                    $fromtime=IntegerDate(date('Y-m-d h:m:s'));
                    $to=IntegerDate(date('Y-m-d h:m:s'));
                    $check=GetActivityTime($empl[$i]->id,$fromtime,$to);
                    if($check)
                    {
                        updateByWhere('employee',array('fromtime'=>$to),array('emplId'=>$empl[$i]->id));
                    }

                } 
                
            }
        }
         
      
        echo 'records done';
        die;
    }



    ///CroneJobes
    public function GetCroneJobes()
    {
        $check = CroneJobes();
        if ($check) {
            echo 'Done CroneJobes';
            die;
        }
    }





    ///Logout 
    public function Logout()
    {

        session_destroy();
        redirect('login');
    }
}

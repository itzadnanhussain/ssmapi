<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Partial extends CI_Controller
{
    ///check login
    function __construct()
    {
        parent::__construct();
        ///load Helper
        $this->load->helper('functions_helper');
        $this->load->helper('queries_helper');
        if ($_SESSION['logged_in'] != true) {
            redirect('login');
        }
    }


    ///ApiSetConfigValue
    public function ApiSetConfigValue()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            if ($value == 1) {
                $value = true;
            }
            if ($value == 0) {
                $value = false;
            }

            $response = SetConfigValue($empId, $key, $value);
            if ($response == 1) {
                ///Success
                $data = array('code' => 'success', 'message' => 'Status Updated');
                echo json_encode($data);
                die;
            } else {
                ///credential not correct
                $data = array('code' => 'warning', 'message' => 'Something Wrong');
                echo json_encode($data);
                die;
            }
        }
    }


    ///PostProjectLimit
    public function PostProjectWeeklyLimit()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST); 
            $where = array('emplId' => $emplId, 'projectId' => $projectId);
            $data = array('emplId' => $emplId, 'projectId' => $projectId, 'weeklylimit' => $weeklylimit,'notifi_email'=>$notifi_email);
            $check = getByWhere('weeklylimit', '*', $where);
            

            if ($check) {
                $update = updateByWhere('weeklylimit', $data, $where);
                if ($update) {
                    $executeCrons = CroneJobes();
                    if ($executeCrons) {
                        ///Success
                        $data = array('code' => 'success', 'message' => 'Record Has Been Updated');
                        echo json_encode($data);
                        die;
                    }
                }
            } else {
                $add = addNew('weeklylimit', $data);
                if ($add) {
                    $executeCrons = CroneJobes();
                    if ($executeCrons) {
                        ///Success
                        $data = array('code' => 'success', 'message' => 'Record Has Been Updated');
                        echo json_encode($data);
                        die;
                    }
                }
            }
        }
    }
}

<div class="content-wrapper">
    <div class="row">
    <div class="col-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Records Search By Client</h4>
                  <p class="card-description">
                   Here You Have Accessbilty To View Employee List By Client
                  </p>
                  <form class="form-inline" id="clientForm">
                    <div class="form-group">
                        <select name="client_id" id="" class="form-control mb-2 mr-sm-2">
                            <option value="52033l664d7349b4d71e273adbd19e2197745f" <?php echo (isset($client_id) && ($client_id=='52033l664d7349b4d71e273adbd19e2197745f')) ? 'selected' : '' ?>>52033l664d7349b4d71e273adbd19e2197745f</option>
                            <option value="45605ld4a2c8d08e3fd5a6e6aa74e9cc982a2c" <?php echo (isset($client_id) && ($client_id=='45605ld4a2c8d08e3fd5a6e6aa74e9cc982a2c')) ? 'selected' : '' ?>>45605ld4a2c8d08e3fd5a6e6aa74e9cc982a2c</option>
                        </select> 
                    </div>
                    <button type="submit" class="btn btn-primary mb-2" id="btn-sbmit">Search</button>
                  </form>
                </div>
              </div>
            </div>
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Total Number Of Employee <div class="badge badge-pill badge-success"><?php echo (isset($count)) ? $count : ''  ?></div></h4>
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive">
                                <div id="order-listing_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table class="table dataTable no-footer" id="data-table" role="grid" aria-describedby="order-listing_info">
                                                <thead>
                                                    <tr class="bg-primary text-white">
                                                        <th>#id</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>            
                                                <tbody>
                                                <?php if (isset($tr) && !empty($tr)) {
                                                        for ($i = 0; $i < $count; $i++) {
                                                            echo  $tr[$i];
                                                        }
                                                    } ?> 
                                                     
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
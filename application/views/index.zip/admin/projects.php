<div class="content-wrapper">
    <div class="row">
        <div class="col-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Records Search By Client</h4>
                    <p class="card-description">
                        Here You Have Accessbilty To View Projects List By Client
                    </p>
                    <form class="form-inline" id="clientForm">
                        <div class="form-group">
                            <select name="client_id" id="" class="form-control mb-2 mr-sm-2">
                                <option value="52033l664d7349b4d71e273adbd19e2197745f" <?php echo (isset($client_id) && ($client_id == '52033l664d7349b4d71e273adbd19e2197745f')) ? 'selected' : '' ?>>52033l664d7349b4d71e273adbd19e2197745f</option>
                                <option value="45605ld4a2c8d08e3fd5a6e6aa74e9cc982a2c" <?php echo (isset($client_id) && ($client_id == '45605ld4a2c8d08e3fd5a6e6aa74e9cc982a2c')) ? 'selected' : '' ?>>45605ld4a2c8d08e3fd5a6e6aa74e9cc982a2c</option>
                            </select>

                        </div>
                        <button type="submit" class="btn btn-primary mb-2" id="btn-sbmit">Search</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Total Number Of Projects <div class="badge badge-pill badge-success"><?php echo (isset($count)) ? $count : ''  ?></div>
                    </h4>

                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive">
                                <div id="order-listing_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <style>
                                                .dataTable thead>tr>th {
                                                    font-size: 11px;
                                                }

                                                .actions-links a>i {
                                                    font-size: 20px !important;
                                                    color: darkblue;
                                                    margin-right: 15px;
                                                }
                                            </style>
                                            <table class="table dataTable no-footer" id="data-table" role="grid" aria-describedby="order-listing_info">
                                                <thead>
                                                    <tr class="bg-primary text-white">
                                                        <th>#id</th>
                                                        <th>Name</th>
                                                        <th>Works By Month</th>
                                                        <th>Monthly Limit</th>
                                                        <th>Progress</th>
                                                        <th>Email</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php if (isset($tr) && !empty($tr)) {
                                                        for ($i = 0; $i < $count; $i++) {
                                                            echo  $tr[$i];
                                                        }
                                                    } ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<!-- -Model--->
<div class="modal fade" id="projectModal" tabindex="-1" role="dialog" aria-labelledby="projectModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="projectModalLabel">You Can Change Monthly Limit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="month-limit" action="<?php echo base_url('PostProjectMonthlyLimit') ?>">
                    <input type="hidden" class="projectId" name="project_id" value="">
                    <div class="form-group">
                        <label for="">Monthly Limit</label>
                        <input type="number" name="month_limit" min="0" value="" class="form-control">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" id="btn-sbmit">Send Updates</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
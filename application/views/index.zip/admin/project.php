<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card d-none d-md-flex">
            <div class="card">
                <div class="card-body">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home-1" role="tab" aria-controls="home-1" aria-selected="true">Project Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile-1" role="tab" aria-controls="profile-1" aria-selected="false">Employees</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact-1" role="tab" aria-controls="contact-1" aria-selected="false">Settings</a>
                        </li>
                    </ul> 

                    <div class="tab-content">
                        <div class="tab-pane fade active show" id="home-1" role="tabpanel" aria-labelledby="home-tab">

                            <?php if (isset($records) && !empty($records)) { ?>

                                <div class="border-bottom text-center pb-4">
                                    <!-- <div class="mb-3">
                                        <h3><?php echo (isset($records[0]->name) ? $records[0]->name : 'Name') ?></h3>
                                    </div> -->
                                    <div class="border-bottom py-4">
                                        <div class="d-flex mb-3">
                                            <div class="progress progress-md flex-grow">
                                                <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="55" style="width: 55%" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                        <div class="d-flex">
                                            <div class="progress progress-md flex-grow">
                                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="75" style="width: 75%" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="py-4">
                                        <p class="clearfix">
                                            <span class="float-left">
                                                Project ID
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($records[0]->project_id) ? $records[0]->project_id : '') ?>
                                            </span>
                                        </p>
                                        <p class="clearfix">
                                            <span class="float-left">
                                                Project Name
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($records[0]->name) ? $records[0]->name : '') ?>
                                            </span>
                                        </p>
                                        <p class="clearfix">
                                            <span class="float-left">
                                                Client ID
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($records[0]->client_id) ? $records[0]->client_id : '') ?>
                                            </span>
                                        </p>
                                        <p class="clearfix">
                                            <span class="float-left">
                                                Color
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($records[0]->color) ? $records[0]->color : '') ?>
                                            </span>
                                        </p>
                                        <p class="clearfix">
                                            <span class="float-left">
                                                End Date
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($records[0]->endDate) ? $records[0]->endDate : 'Not Set ') ?>
                                            </span>
                                        </p>
                                        <p class="clearfix">
                                            <span class="float-left">
                                                Week Limit
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($records[0]->week_limit) ? $records[0]->week_limit : 'Not Set ') ?>
                                            </span>
                                        </p>
                                        <p class="clearfix">
                                            <span class="float-left">
                                               Total Working Hours
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo  ProjectTotalCoveredWeekHours($records[0]->project_id); ?>
                                            </span>
                                        </p>


                                    </div>

                                </div>
                            <?php } ?>

                        </div>

                        <div class="tab-pane fade" id="profile-1" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="media">

                                <div class="table-responsive">
                                    <table id="data-table" class="table">
                                        <h5>Total Number Of Employees Working On This Project </h5>

                                        <thead>
                                            <tr class="bg-primary text-white">
                                                <th>S.No</th>
                                                <th>#EmployeeID</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Total Work</th> 
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php if (isset($emp) && !empty($emp)) { ?>
                                                 
                                                <?php $i=1 ;?>
                                                <?php foreach ($emp as $key => $value) { ?>
                                                    <tr>
                                                        <td><?php echo $i ?></td>
                                                        <td><?php echo $value->emplId ?></td>
                                                        <td><?php echo  $value->name ?></td>
                                                        <td><?php echo $value->email ?></td>
                                                        <td><?php echo ($value->total_work_hours!=NULL) ? $value->total_work_hours .'hrs' : 'No Data' ?></td>

                                                         
                                                    </tr>
                                                    <?php $i++ ;?>

                                                <?php } ?>

                                            <?php } ?>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>

                         <div class="tab-pane fade" id="contact-1" role="tabpanel" aria-labelledby="contact-tab">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Project Configration</h4>
                                    <form class="submit-form"> 
                                         <div class="form-group">
                                             <input type="hidden" name="project_id" value="<?php echo $records[0]->project_id ?>">  
                                        </div> 
                                        <div class="form-group">
                                            <label for="">Previous Project Week Limit</label>
                                            <input type="text"  value="<?php echo ($records[0]->week_limit != NULL) ? $value->total_work_hours : 'No Limit Set' ?>" class="form-control" disabled>

                                        </div> 
                                        <div class="form-group">
                                            <label for="">Select Project Week Limit</label>
                                            <input type="number" name="week_limit" min="0" class="form-control">

                                        </div> 
                                        <button type="submit" class="btn btn-primary mr-2">Submit</button>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card d-none d-md-flex">
            <div class="card">

                <div class="card-body">
                    <ul class="nav nav-tabs" role="tablist">
                      
                       
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home-1" role="tab" aria-controls="home-1" aria-selected="true">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile-1" role="tab" aria-controls="profile-1" aria-selected="false">Projects</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact-1" role="tab" aria-controls="contact-1" aria-selected="false">API Settings</a>
                        </li>
                    </ul>


                    <div class="tab-content"> 

                        <div class="tab-pane fade active show" id="home-1" role="tabpanel" aria-labelledby="home-tab">

                            <?php if (isset($profile) && !empty($profile)) { ?>

                                <div class="border-bottom text-center pb-4">
                                    <img src="https://via.placeholder.com/92x92" alt="profile" class="img-lg rounded-circle mb-3">
                                    <div class="mb-3">
                                        <h3><?php echo (isset($profile['name']) ? $profile['name'] : 'Nothing') ?></h3>
                                    </div>
                                    <div class="border-bottom py-4">
                                        <div class="d-flex mb-3">
                                            <div class="progress progress-md flex-grow">
                                                <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="55" style="width: 55%" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                        <div class="d-flex">
                                            <div class="progress progress-md flex-grow">
                                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="75" style="width: 75%" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="py-4">
                                        <p class="clearfix">
                                            <span class="float-left">
                                                Employee ID
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($profile['id']) ? $profile['id'] : 'Nothing') ?>
                                            </span>
                                        </p>

                                        <p class="clearfix">
                                            <span class="float-left">
                                                Email
                                            </span>
                                            <span class="float-right text-muted">
                                                <a href="#"><?php echo (isset($profile['email']) ? $profile['email'] : 'Nothing') ?> </a>
                                            </span>
                                        </p>
                                        <p class="clearfix">
                                            <span class="float-left">
                                                Total Projects
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($totalProjects) ? $totalProjects : 'Nothing') ?>
                                            </span>
                                        </p>
                                        <p class="clearfix">
                                            <span class="float-left">
                                                Auto Pause Minutes
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($config['autoPauseMinutes']) ? $config['autoPauseMinutes'] : 0) ?>
                                            </span>
                                        </p>

                                        <p class="clearfix">
                                            <span class="float-left">
                                                Weekly Limit
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($config['weeklyLimit']) ? $config['weeklyLimit'] : 'Nothing') ?>


                                            </span>
                                        </p>

                                        <p class="clearfix">
                                            <span class="float-left">
                                                Disable Offline Time
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($config['disableOfflineTime']) && ($config['disableOfflineTime'] == 1) ?  "True" : 'False') ?>
                                            </span>
                                        </p>

                                        <p class="clearfix">
                                            <span class="float-left">
                                                Disable Screenshot Notification
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($config['disableScreenshotNotification']) && ($config['disableScreenshotNotification'] == 1) ? "True" : "False") ?>
                                            </span>
                                        </p>


                                        <p class="clearfix">
                                            <span class="float-left">
                                                Disable Activity Level
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($config['disableActivityLevel']) && ($config['disableActivityLevel'] == 1) ? "True" : "False") ?>
                                            </span>
                                        </p>


                                        <p class="clearfix">
                                            <span class="float-left">
                                                Week Start Day
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($config['weekStartDay']) ? $config['weekStartDay'] : "Not Set") ?>
                                            </span>
                                        </p>


                                        <p class="clearfix">
                                            <span class="float-left">
                                                Currency
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($config['currency']) ? $config['currency'] : 0) ?>
                                            </span>
                                        </p>

                                        <p class="clearfix">
                                            <span class="float-left">
                                                Disable App Tracking
                                            </span>
                                            <span class="float-right text-muted">
                                                <?php echo (isset($config['disableAppTracking']) && ($config['disableAppTracking'] == 1) ? "True" : "False") ?>
                                            </span>
                                        </p>

                                    </div>

                                </div>
                            <?php } ?>

                        </div> 
                        <div class="tab-pane fade" id="profile-1" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="media">
                                <div class="table-responsive">
                                    <table id="data-table" class="table">
                                        <thead>
                                            <tr class="bg-primary text-white">
                                                <th>#Project ID</th>
                                                <th>Project Name</th>
                                                <th>Weekly Limit</th>
                                                <th>working Hours</th>
                                                <th>status</th>
                                                <th>Notification Email</th>
                                                <th>Actions</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php if (isset($projects) && !empty($projects)) { ?>
                                                <?php foreach ($projects as $key => $value) { ?> 
                                                    <tr>
                                                        <td><?php echo (isset($value->projectId) ? substr($value->projectId, 0, 10) . '...' : 'Nothing') ?></td>
                                                        <td><?php echo ProjectName($value->projectId) ?></td>
                                                        <td><?php echo WeekTotalLimit($value->projectId, $profile['id']); ?></td>
                                                        <td><?php echo WeekTotalWorkingTime($value->projectId, $profile['id']) . ' hr' ?></td>
                                                        <td><?php echo WorkStatusFinder($value->projectId, $profile['id']) ?></td>
                                                        <td><?php echo GetNotifiEmail($value->projectId, $profile['id']) ?></td>
                                                        <td><a type="button" data-toggle="modal" data-target="#exampleModal" data-whatever="<?php echo $value->projectId ?>"><i class="mdi mdi-pencil-box" style="font-size: 29px;color: darkblue;margin-left: 23px;"></i></a></td>

                                                    </tr>

                                                <?php } ?>

                                            <?php } ?>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>



                        <div class="tab-pane fade" id="contact-1" role="tabpanel" aria-labelledby="contact-tab">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Employee Configration</h4>
                                    <form class="submit-form" action="<?php echo base_url('ApiSetConfigValue') ?>">

                                        <input type="hidden" name="empId" value="<?php echo $profile['id'] ?>">
                                        <div class="form-group">
                                            <select name="key" class="form-control" onchange="ViewKey(this.value)">
                                                <option value=" ">Select key</option>
                                                <option value="disableOfflineTime">disableOfflineTime</option>
                                                <option value="disableScreenshotNotification">disableScreenshotNotification</option>
                                                <option value="disableActivityLevel">disableActivityLevel</option>
                                                <option value="currency">currency</option>
                                                <option value="weeklyLimit">weeklyLimit</option>
                                                <option value="weekStartDay">weekStartDay</option>
                                                <option value="disableAppTracking">disableAppTracking</option>
                                            </select>
                                        </div>

                                        <div class="form-group" id="true-false" style="display: none;">
                                            <label>Select Flag</label>
                                            <select name="value" class="form-control" disabled>
                                                <option value="1">True</option>
                                                <option value="0">False</option>
                                            </select>
                                        </div>

                                        <div class="form-group" id="time" style="display: none;">
                                            <label>Enter value</label>
                                            <input type="text" name="value" class="form-control" disabled>
                                        </div>


                                        <button type="submit" class="btn btn-primary mr-2">Submit</button>

                                    </form>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>

    </div>

</div>



<!-- -Model--->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Weekly Limit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="submit-limit">
                    <div class="form-group">
                        <input type="hidden" class="form-control" name="emplId" value="<?php echo $profile['id'] ?>">
                        <input type="hidden" class="form-control projectId" name="project_id">
                        <input type="hidden" class="form-control" name="client_id" value="<?php echo $client_id ?>">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control projectId" disabled>
                    </div>
                    <div class="form-group">
                        <label>Enter Weekly Limit</label>
                        <input type="number" name="week_limit" class="form-control" min="0" minlength="0" required>
                    </div>

                    <div class="form-group">
                        <label>Notification Email</label>
                        <input type="text" name="notifi_email" class="form-control">
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" id="btn-sbmit">Send Updates</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div> 
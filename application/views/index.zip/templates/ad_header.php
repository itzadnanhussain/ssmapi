<!DOCTYPE html>
<html lang="en"> 
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Screenshot</title>
  <!-- base:css -->
  <link rel="stylesheet" href="<?php echo base_url('assets/') ?>vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/') ?>vendors/base/vendor.bundle.base.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/') ?>vendors/datatables.net-bs4/dataTables.bootstrap4.css">
 
  <link rel="stylesheet" href="<?php echo base_url('assets/') ?>css/vertical-layout-light/style.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/') ?>css/vertical-layout-light/custom.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/') ?>vendors/jquery-toast-plugin/jquery.toast.min.css"> 

  <link rel="shortcut icon" href="<?php echo base_url('assets/') ?>images/favicon.png" />
</head>

<body class="sidebar-fixed">
  <div class="container-scroller">
    <!--Top Navigation Bar -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-left navbar-brand-wrapper d-flex align-items-center justify-content-between">
        <a class="navbar-brand brand-logo" href="<?php echo base_url() ?>">Screenshot</a>
        <a class="navbar-brand brand-logo-mini" href="index.html"></a>
        <button class="navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <ul class="navbar-nav">
          <li class="nav-item  dropdown d-none align-items-center d-lg-flex d-none">
            <a class="dropdown-toggle btn btn-outline-secondary btn-fw" href="#" data-toggle="dropdown" id="pagesDropdown">
              <span class="nav-profile-name">Account</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="pagesDropdown">
              <!-- <a class="dropdown-item">
                <i class="mdi mdi-settings text-primary"></i>
                Settings
              </a> -->
              <a class="dropdown-item" href="<?php echo base_url('logout') ?>">
                <i class="mdi mdi-logout text-primary"></i>
                Logout
              </a>
            </div>
          </li>

        </ul>

        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav"> 
          <!-- <li class="nav-item">
            <a class="nav-link" href="index.html">
              <i class="mdi mdi-shield-check menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li> -->

          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('employees') ?>">
              <i class="mdi mdi-shield-check menu-icon"></i>
              <span class="menu-title">Employee</span>
            </a>
          </li>


          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('projects') ?>">
              <i class="mdi mdi-poll menu-icon"></i>
              <span class="menu-title">Projects</span>
            </a>
          </li>

        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
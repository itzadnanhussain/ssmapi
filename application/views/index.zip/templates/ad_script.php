<script>
    ///load Data
    $('#data-table').DataTable();


    function ViewKey(value) {
        switch (value) {
            case "disableOfflineTime":
                $('#true-false').css('display', 'block');
                $('#true-false select').attr('disabled', false);

                ///time
                $('#time').css('display', 'none');
                $('#time input').attr('disabled', true);

                break;

            case "disableScreenshotNotification":
                $('#true-false').css('display', 'block');
                $('#true-false select').attr('disabled', false);

                ///time
                $('#time').css('display', 'none');
                $('#time input').attr('disabled', true);

                break;

            case "disableActivityLevel":
                $('#true-false').css('display', 'block');
                $('#true-false select').attr('disabled', false);

                ///time
                $('#time').css('display', 'none');
                $('#time input').attr('disabled', true);

                break;

            case "disableAppTracking":
                $('#true-false').css('display', 'block');
                $('#true-false select').attr('disabled', false);

                ///time
                $('#time').css('display', 'none');
                $('#time input').attr('disabled', true);

                break;


            case "weeklyLimit":
                ///time
                $('#time').css('display', 'block');
                $('#time input').attr('disabled', false);

                ///true-false
                $('#true-false').css('display', 'none');
                $('#true-false select').attr('disabled', true);
                break;

            case "autoPauseMinutes":
                ///time
                $('#time').css('display', 'block');
                $('#time input').attr('disabled', false);

                ///true-false
                $('#true-false').css('display', 'none');
                $('#true-false select').attr('disabled', true);
                break;
            case "currency":
                ///time
                $('#time').css('display', 'block');
                $('#time input').attr('disabled', false);

                ///true-false
                $('#true-false').css('display', 'none');
                $('#true-false select').attr('disabled', true);
                break;
            case "weekStartDay":
                ///time
                $('#time').css('display', 'block');
                $('#time input').attr('disabled', false);

                ///true-false
                $('#true-false').css('display', 'none');
                $('#true-false select').attr('disabled', true);
                break;
            case " ":
                ///time
                $('#time').css('display', 'none');
                $('#time input').attr('disabled', true);

                ///true-false
                $('#true-false').css('display', 'none');
                $('#true-false select').attr('disabled', true);
                break;


        }

    }


    ////Post Form
    $('.submit-form').submit(function(e) {
        e.preventDefault();
        e.stopPropagation();
        let form = $(this).serialize();
        let url = $('.submit-form').attr('action');
        $.ajax({
            type: 'POST',
            url: url,
            data: form,
            dataType: 'html',
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        showSuccessToast(res.message);
                        setTimeout(function() {
                            window.location.reload();
                        }, 3500)
                        break;
                    case 'warning':
                        showWarningToast(res.message);
                        break;

                }
            }
        });
    })


    ////Post Limit
    $('.submit-limit').submit(function(e) {
        e.preventDefault();
        e.stopPropagation();
        let form = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('PostProjectWeeklyLimit') ?>',
            data: form,
            dataType: 'html',
            beforeSend: function() {
                $('#btn-sbmit').text('processing...');

            },
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        showSuccessToast(res.message);
                        setTimeout(function() {
                            ///  $('#exampleModal').modal('hide')
                            window.location.reload();
                        }, 3500)
                        break;
                    case 'warning':
                        showWarningToast(res.message);
                        break;

                }
            },
            complete: function() {
                $('#btn-sbmit').text('Success Submition');

            },

        });
    })

    $('#exampleModal').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var projectId = button.data('whatever')
        var modal = $(this)
        modal.find('.projectId').val(projectId)
    });


    $('#clientForm').submit(function(e) {
        e.preventDefault();
        e.stopPropagation();
        let form = $(this).serialize();
        $.ajax({
            type: 'POST',
            data: form,
            dataType: 'html',
            beforeSend: function() {
                $('#btn-sbmit').text('processing...');
                $('#btn-sbmit').attr('disabled', true);

            },
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        showSuccessToast(res.message);
                        setTimeout(function() {
                            window.location.reload();
                        }, 3500)
                        break;
                    case 'warning':
                        showWarningToast(res.message);
                        break;

                }
            },
            complete: function() {
                $('#btn-sbmit').text('Success');

            },
        });
    })


    $('#projectModal').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var projectId = button.data('whatever')
        var modal = $(this)
        modal.find('.projectId').val(projectId)
    });


    //General Form
    $('.month-limit').submit(function(e) {
        e.preventDefault();
        e.stopPropagation();
        let form = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: $('.month-limit').attr('action'),
            data: form,
            dataType: 'html',
            beforeSend: function() {
                $('#btn-sbmit').text('processing...');
                $('#btn-sbmit').attr('disabled', true);

            },
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        showSuccessToast(res.message);
                        setTimeout(function() {
                            window.location.reload();
                        }, 3500)
                        break;
                    case 'warning':
                        showWarningToast(res.message);
                        break;

                }
            },
            complete: function() {
                $('#btn-sbmit').text('Success');

            },
        });
    })
</script>
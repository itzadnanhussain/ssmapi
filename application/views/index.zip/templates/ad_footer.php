 <!-- content-wrapper ends -->
 <!-- partial:partials/_footer.html -->
 <div class="footer-wrapper">
   <footer class="footer">
     <div class="d-sm-flex justify-content-center justify-content-sm-between">
       <span class="text-center text-sm-left d-block d-sm-inline-block">Copyright &copy; <?php echo date('Y') ?>. All rights reserved. </span>

     </div>
   </footer>
 </div>
 <!-- partial -->
 <!-- main-panel ends -->
 </div>
 <!-- page-body-wrapper ends -->
 </div>
 </div>


 
 <!-- container-scroller -->
 <!-- base:js -->
 <script src="<?php echo base_url('assets/') ?>vendors/base/vendor.bundle.base.js"></script> 
 <script src="<?php echo base_url('assets/') ?>js/off-canvas.js"></script>
 <script src="<?php echo base_url('assets/') ?>js/hoverable-collapse.js"></script>
 <script src="<?php echo base_url('assets/') ?>js/template.js"></script>
 <script src="<?php echo base_url('assets/') ?>js/settings.js"></script>
 <script src="<?php echo base_url('assets/') ?>js/todolist.js"></script> 
 <!-- Custom js for this page-->
 <script src="<?php echo base_url('assets/') ?>js/dashboard.js"></script>
 <!-- plugin js for this page -->
 <script src="<?php echo base_url('assets/') ?>vendors/datatables.net/jquery.dataTables.js"></script>
 <script src="<?php echo base_url('assets/') ?>vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
 <script src="<?php echo base_url('assets/') ?>vendors/jquery-toast-plugin/jquery.toast.min.js"></script>
 <script src="<?php echo base_url('assets/') ?>js/toastDemo.js"></script> 
 <?php $this->load->view('templates/ad_script') ?>
 <!-- End custom js for this page--> 
 <!---Check Script File---->
 <script src="<?php echo base_url('assets/') ?>js/custom.js"></script>



 </body>

 </html>
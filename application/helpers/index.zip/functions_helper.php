<?php
defined('BASEPATH') or exit('No direct script access allowed');

/////Helper Function For Login Views//////
if (!function_exists('AdminView')) {
    function AdminView($page, $data = array(), $title)
    {
        $thiz = &get_instance();
        $data['title'] = $title;
        $thiz->load->view('templates/ad_header', $title);
        $thiz->load->view($page, $data);
        $thiz->load->view('templates/ad_footer');
        // $thiz->load->view('templates/ad_footer',array('ad_scriptfile'=>basename($page))); 
    }
}


///GetCommonData
if (!function_exists('GetCommonData')) {
    function GetCommonData()
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://screenshotmonitor.com/api/v2/GetCommonData',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HTTPHEADER => array(
                'X-SSM-Token: 52033l664d7349b4d71e273adbd19e2197745f',
                'Content-Type: application/json; charset=utf-8',
                'Accept: application/json; charset=utf-8',
                'Content-Length: 0',
            ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        $data = json_decode($response);
        return $data;
    }
}



///GetActivities
if (!function_exists('GetActivities')) {
    function GetActivities($empId, $from, $to)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://screenshotmonitor.com/api/v2/GetActivities',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => '[{
            "employmentId": ' . $empId . ',
            "from": ' . $from . ',
            "to": ' . $to . '
        }]',
            CURLOPT_HTTPHEADER => array(
                'X-SSM-Token: 52033l664d7349b4d71e273adbd19e2197745f',
                'Content-Type: application/json',
                'Cookie: VisitorID=841914e1-ee52-47f8-bca1-7f2b5fee5a9c'
            ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        $data = json_decode($response);
        return $data;
    }
}


///GetCommonData
if (!function_exists('SetConfigValue')) {
    function SetConfigValue($empId, $key, $value)
    {
        $url = 'https://screenshotmonitor.com/api/v2/SetConfigValue';
        $data = array(
            "employmentId" => $empId,
            "key" => $key,
            "value" => $value

        );
        $postdata = json_encode($data);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'X-SSM-Token: 52033l664d7349b4d71e273adbd19e2197745f'));
        curl_exec($ch);
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($http_status == 200) {
            return 1;
        } else {
            return 0;
        }
    }
}


///GetIntegerDate
if (!function_exists('IntegerDate')) {
    function IntegerDate($date)
    {
        return strtotime($date);
    }
}


///TotalHours
if (!function_exists('TotalHours')) {
    function TotalHours($date1, $date2)
    {
        return abs($date2 - $date1) / (60 * 60);
    }
}



///ProjectName
if (!function_exists('ProjectName')) {
    function ProjectName($id)
    {
        $data = getByWhere('projects', 'name', array('id' => $id));
        return $data[0]->name;
    }
}


///WeekTotalLimit
if (!function_exists('WeekTotalLimit')) {
    function WeekTotalLimit($projectId, $emplId)
    {
        // $thiz=&get_instance();
        $data = getByWhere('weeklylimit', 'weeklylimit', array('projectId' => $projectId, 'emplId' => $emplId));
        // echo $thiz->db->last_query();
        // die;
        if (isset($data) && !empty($data) && $data[0]->weeklylimit != NULL) {
            return $data[0]->weeklylimit;
        } else {
            return "0";
        }
    }
}


///WeekTotalLimit
if (!function_exists('WeekTotalWorkingTime')) {
    function WeekTotalWorkingTime($projectId, $emplId)
    {
        // $thiz=&get_instance();
        $data = getByWhere('weeklylimit', 'workhours', array('projectId' => $projectId, 'emplId' => $emplId));
        // echo $thiz->db->last_query();
        // die;
        if (isset($data) && !empty($data) && $data[0]->workhours != NULL) {
            return $data[0]->workhours;
        } else {
            return "0";
        }
    }
}



///WeekTotalLimit
if (!function_exists('WorkStatusFinder')) {
    function WorkStatusFinder($projectId, $emplId)
    {

        $data = getByWhere('weeklylimit', '*', array('projectId' => $projectId, 'emplId' => $emplId));
        if ($data[0]->flag25 == "active") {
            $html = '<div class="badge badge-danger badge-pill">25%</div>';
            return $html;
        } else if ($data[0]->flag50 == "active") {

            $html = '<div class="badge badge-warning badge-pill">50%</div>';
            return $html;
        } else if ($data[0]->flag75 == "active") {
            $html = '<div class="badge badge-info badge-pill">75%</div>';
            return $html;
        } else if ($data[0]->flag100 == "active") {
            $html = '<div class="badge badge-success badge-pill">100%</div>';
            return $html;
        } else {
            $html = '<div class="badge badge-danger badge-pill">0%</div>';
            return $html;
        }
    }
}


///WeekTotalLimit
if (!function_exists('GetNotifiEmail')) {
    function GetNotifiEmail($projectId, $emplId)
    {

        $data = getByWhere('weeklylimit', 'notifi_email', array('projectId' => $projectId, 'emplId' => $emplId));
        if ($data[0]->notifi_email == NULL) {

            return  $_SESSION['company_email'];
        } else {
            return $data[0]->notifi_email;
        }
    }
}


///GetActivityTime
if(!function_exists('GetActivityTime'))
{
    function GetActivityTime($emplId,$from,$to)
    {
        $data = GetActivities($emplId, $from, $to);  
        if (isset($data) && !empty($data)) {
            $count = count($data);
            for ($i = 0; $i < $count; $i++) {
                $from = $data[$i]->from;
                $to = $data[$i]->to;
                $worktime = TotalHours($from, $to);
                $getData=getByWhere('weeklylimit','workhours',array('emplId'=>$data[$i]->employmentId,'projectId'=>$data[$i]->projectId));
              
                if($getData)
                {
                     $currentworkingtime=$getData[0]->workhours;
                     $updateworkhours=round($worktime+$currentworkingtime);
                     updateByWhere('weeklylimit',array('workhours'=>$updateworkhours),array('emplId'=>$data[$i]->employmentId,'projectId'=>$data[$i]->projectId));


                }
                else
                {
                    $data['projectId']=$data[$i]->projectId;
                    $data['emplId']=$data[$i]->employmentId;
                    $data['workhours']=$worktime; 
                    addNew('weeklylimit',$data);
                }
            }
        }
        return 1; 
       
    }
}


///CroneJobes
if (!function_exists('CroneJobes')) {
    ///CroneJobes
    function CroneJobes()
    {

        $records = GetCommonData();
        ///Project Table Update
        $projects = $records->companies[0]->projects;
        $AdminEmail = $records->companies[0]->employments[0]->email;
        $_SESSION['company_email'] = $records->companies[0]->employments[0]->email;
        if (isset($projects) && (!empty($projects))) {
            $count = count($projects);
            for ($i = 0; $i < $count; $i++) {
                //data
                $data = array();
                $data['id'] = $projects[$i]->id;
                $data['name'] = $projects[$i]->name;
                $data['color'] = $projects[$i]->color;
                $data['clientId'] = $projects[$i]->clientId;
                $data['endDate'] = $projects[$i]->endDate;

                $check = getByWhere('projects', '*', array('id' => $projects[$i]->id));
                if (empty($check)) {
                    addNew('projects', $data);
                } else {
                    updateByWhere('projects', $data, array('id' => $projects[$i]->id));
                }
            }
        }

        ////Weeklylimit Table
        $empl = $records->companies[0]->employments;
        if (isset($empl) && !empty($empl)) {
            $count = count($empl);

            for ($i = 0; $i < $count; $i++) {
                $innercount = count($empl[$i]->projects);
                $projects = array();
                $projects = $empl[$i]->projects;

                ///inner loop
                for ($j = 0; $j < $innercount; $j++) {
                    $data = array();
                    $data['emplId'] = $projects[$j]->employmentId;
                    $data['projectId'] = $projects[$j]->projectId;  
                    ///get working hours 
                    $where = array();
                    $where = array('projectId' => $data['projectId'], 'emplId' => $data['emplId']);
                    $check = getByWhere('weeklylimit', '*', $where);
                    if ($check) {

                        updateByWhere('weeklylimit', $data, $where); 
                        ////work for email
                        $getAgain = array();
                        $getAgain = getByWhere('weeklylimit', '*', $where);
                        $limit = $getAgain[0]->weeklylimit;
                        $work = $getAgain[0]->workhours;
                        $notifi_email = $getAgain[0]->notifi_email;
                        if ($notifi_email == NULL) {
                            $notifi_email = $AdminEmail;
                        } 

                        if (($limit != NULL) && ($work != NULL)) {

                            $result = ($work / $limit) * 100; 
                            ///25% Notification
                            if ($result >= 25 && $result < 50) {
                                $status = $getAgain[0]->flag25;
                                if ($status == 'inactive') {
                                    $mailData = array();
                                    $mailData = array(
                                        'id' => $empl[$i]->id,
                                        'name' => $empl[$i]->name,
                                        'email' => $empl[$i]->email,
                                        'projectId' => $projects[$j]->projectId,
                                        'projectname' => ProjectName($projects[$j]->projectId),
                                        'workdone' => "25%",

                                    );



                                    $checkmail = sendEmail($mailData, $notifi_email);
                                    if ($checkmail) {
                                        updateByWhere('weeklylimit', array('flag25' => 'active', 'flag50' => 'inactive', 'flag75' => 'inactive', 'flag100' => 'inactive'), $where);
                                    }
                                }
                            }

                            ///50% Notification
                            if ($result >= 50 && $result < 75) {
                                $status = $getAgain[0]->flag50;
                                if ($status == 'inactive') {
                                    $mailData = array();
                                    $mailData = array(
                                        'id' => $empl[$i]->id,
                                        'name' => $empl[$i]->name,
                                        'email' => $empl[$i]->email,
                                        'projectId' => $projects[$j]->projectId,
                                        'projectname' => ProjectName($projects[$j]->projectId),
                                        'workdone' => "50%",

                                    );


                                    $checkmail = sendEmail($mailData, $notifi_email);
                                    if ($checkmail) {
                                        updateByWhere('weeklylimit', array('flag25' => 'inactive', 'flag50' => 'active', 'flag75' => 'inactive', 'flag100' => 'inactive'), $where);
                                    }
                                }
                            }

                            ///75% Notification
                            if ($result >= 75 && $result < 100) {
                                $status = $getAgain[0]->flag75;
                                if ($status == 'inactive') {
                                    $mailData = array();
                                    $mailData = array(
                                        'id' => $empl[$i]->id,
                                        'name' => $empl[$i]->name,
                                        'email' => $empl[$i]->email,
                                        'projectId' => $projects[$j]->projectId,
                                        'projectname' => ProjectName($projects[$j]->projectId),
                                        'workdone' => "75%",

                                    );



                                    $checkmail = sendEmail($mailData, $notifi_email);
                                    if ($checkmail) {
                                        updateByWhere('weeklylimit', array('flag25' => 'inactive', 'flag50' => 'inactive', 'flag75' => 'active', 'flag100' => 'inactive'), $where);
                                    }
                                }
                            }


                            ///100% Notification
                            if ($result >= 100) {
                                $status = $getAgain[0]->flag100;
                                if ($status == 'inactive') {
                                    $mailData = array();
                                    $mailData = array(
                                        'id' => $empl[$i]->id,
                                        'name' => $empl[$i]->name,
                                        'email' => $empl[$i]->email,
                                        'projectId' => $projects[$j]->projectId,
                                        'projectname' => ProjectName($projects[$j]->projectId),
                                        'workdone' => "100%",

                                    );


                                    $checkmail = sendEmail($mailData, $notifi_email);
                                    if ($checkmail) {
                                        updateByWhere('weeklylimit', array('flag25' => 'inactive', 'flag50' => 'inactive', 'flag75' => 'inactive', 'flag100' => 'active'), $where);
                                    }
                                }
                            }
                        }

                    } else {

                        addNew('weeklylimit', $data);
                        ////work for email
                        $getAgain = array();
                        $getAgain = getByWhere('weeklylimit', '*', $where);
                        $notifi_email = $getAgain[0]->notifi_email;
                        if ($notifi_email == NULL) {
                            $notifi_email = $AdminEmail;
                        }
                        $limit = $getAgain[0]->weeklylimit;
                        $work = $getAgain[0]->workhours;

                        if (!empty($limit) && !empty($work)) {
                            $result = ($work / $limit) * 100;

                            ///25% Notification
                            if ($result >= 25 && $result < 50) {
                                $status = $getAgain[0]->flag25;
                                if ($status == 'inactive') {
                                    $mailData = array();
                                    $mailData = array(
                                        'id' => $empl[$i]->id,
                                        'name' => $empl[$i]->name,
                                        'email' => $empl[$i]->email,
                                        'projectId' => $projects[$j]->projectId,
                                        'projectname' => ProjectName($projects[$j]->projectId),
                                        'workdone' => "25%",

                                    );



                                    $checkmail = sendEmail($mailData, $notifi_email);
                                    if ($checkmail) {
                                        updateByWhere('weeklylimit', array('flag25' => 'active', 'flag50' => 'inactive', 'flag75' => 'inactive', 'flag100' => 'inactive'), $where);
                                    }
                                }
                            }

                            ///50% Notification
                            if ($result >= 50 && $result < 75) {
                                $status = $getAgain[0]->flag50;
                                if ($status == 'inactive') {
                                    $mailData = array();
                                    $mailData = array(
                                        'id' => $empl[$i]->id,
                                        'name' => $empl[$i]->name,
                                        'email' => $empl[$i]->email,
                                        'projectId' => $projects[$j]->projectId,
                                        'projectname' => ProjectName($projects[$j]->projectId),
                                        'workdone' => "50%",

                                    );


                                    $checkmail = sendEmail($mailData, $notifi_email);
                                    if ($checkmail) {
                                        updateByWhere('weeklylimit', array('flag25' => 'inactive', 'flag50' => 'active', 'flag75' => 'inactive', 'flag100' => 'inactive'), $where);
                                    }
                                }
                            }

                            ///75% Notification
                            if ($result >= 75 && $result < 100) {
                                $status = $getAgain[0]->flag75;
                                if ($status == 'inactive') {
                                    $mailData = array();
                                    $mailData = array(
                                        'id' => $empl[$i]->id,
                                        'name' => $empl[$i]->name,
                                        'email' => $empl[$i]->email,
                                        'projectId' => $projects[$j]->projectId,
                                        'projectname' => ProjectName($projects[$j]->projectId),
                                        'workdone' => "75%",

                                    );



                                    $checkmail = sendEmail($mailData, $notifi_email);
                                    if ($checkmail) {
                                        updateByWhere('weeklylimit', array('flag25' => 'inactive', 'flag50' => 'inactive', 'flag75' => 'active', 'flag100' => 'inactive'), $where);
                                    }
                                }
                            }


                            ///100% Notification
                            if ($result >= 100) {
                                $status = $getAgain[0]->flag100;
                                if ($status == 'inactive') {
                                    $mailData = array();
                                    $mailData = array(
                                        'id' => $empl[$i]->id,
                                        'name' => $empl[$i]->name,
                                        'email' => $empl[$i]->email,
                                        'projectId' => $projects[$j]->projectId,
                                        'projectname' => ProjectName($projects[$j]->projectId),
                                        'workdone' => "100%",

                                    );


                                    $checkmail = sendEmail($mailData, $notifi_email);
                                    if ($checkmail) {
                                        updateByWhere('weeklylimit', array('flag25' => 'inactive', 'flag50' => 'inactive', 'flag75' => 'inactive', 'flag100' => 'active'), $where);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }


        return 1;
    }
}




///sendEmail
if (!function_exists('sendEmail')) {
    ///sendEmail
    function sendEmail($mailData, $notifi_email)
    {


        // Load the email library
        $thiz = &get_instance();
        $thiz->load->library('email');

        // Mail config
        $to = $notifi_email;
        $from = $mailData['email'];
        $fromName = $mailData['name'];
        $mailSubject = 'Contact Request Submitted by ' . $mailData['projectname'];

        // Mail content
        $mailContent = '
           <h2>Contact Request Submitted</h2>
           <p><b>Employee ID: </b>' . $mailData['id'] . '</p>
           <p><b>Employee Name: </b>' . $mailData['name'] . '</p>
           <p><b>Employee Email: </b>' . $mailData['email'] . '</p>
           <p><b>Project ID: </b>' . $mailData['projectId'] . '</p> 
           <p><b>Project Name: </b>' . $mailData['projectname'] . '</p> 
           <p><b>Message: </b>' . $mailData['workdone'] . ' Work Completed in this week' . '</p>
       ';

        $config['mailtype'] = 'html';
        $thiz->email->initialize($config);
        $thiz->email->to($to);
        $thiz->email->from($from, $fromName);
        $thiz->email->subject($mailSubject);
        $thiz->email->message($mailContent);

        // Send email & return status
        return $thiz->email->send() ? true : false;
    }
}
